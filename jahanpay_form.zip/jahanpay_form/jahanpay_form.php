﻿<?php

/*
Plugin Name: فرم پرداخت درگاه جهان پی
Plugin URI: http://jahanpay.me/
Description: فرم پرداخت درگاه اختصاصی جهان پی -::- تمامی حقوق متعلق به پرداخت الکترونیک جهان پی می باشد
Version: 1.0
Author: وب سایت ماژول بانک
Author URI: http://modulebank.ir/
License: Please do not copy. for order or technical support call me at 09160666110 or send email at support@modulebank.ir
*/



function jahanpay_form_menu()
{
	if (function_exists('add_options_page'))
	{
		$capability = 10;
		add_menu_page   ('فرم پرداخت درگاه جهان پی', 'فرم پرداخت درگاه جهان پی', $capability, 'jahanpay_form/setting.php', 'jahanpay_form_setting', plugin_dir_url( __FILE__ ).'jahanpay_form.png');
		add_submenu_page('jahanpay_form/setting.php', 'تنظیمات درگاه', 'تنظیمات درگاه', $capability, 'jahanpay_form/setting.php', 'jahanpay_form_setting');
		add_submenu_page('jahanpay_form/setting.php', 'تاریخچه تراکنش ها', 'تاریخچه تراکنش ها', $capability, 'jahanpay_form/history.php', 'jahanpay_form_history');
	}
}
add_action('admin_menu', 'jahanpay_form_menu');

function jahanpay_form_setting()
{
	if (!current_user_can('manage_options'))
	{
		wp_die('You do not have sufficient permissions to access this page.');
	}
	settings_fields('jahanpay_form_options');
	function register_jahanpay_form()
	{
		register_setting('jahanpay_form_options', 'api');
	}
	require_once('setting.php');
}

function jahanpay_form_history()
{
	if (!current_user_can('manage_options'))
	{
		wp_die('You do not have sufficient permissions to access this page.');
	}
	require_once('history.php');
}

function jahanpay_form()
{
	global $wpdb;
	if(isset($_POST['pay'])&&$_POST['pay'])
	{
		if($_POST['family']&&$_POST['email']&&$_POST['mobile']&&$_POST['price'])
		{
			srand();
			$name        = $_POST['family'];
			$email       = $_POST['email'];
			$mobile      = $_POST['mobile'];
			$price       = (int)$_POST['price'] * 1;
			$description = $_POST['description'];
			$ResNum      = rand(1000000,99999999);
			$sep         = parse_url($_SERVER['REQUEST_URI'],PHP_URL_QUERY)==NULL?'?':'&';
			$callBackURL = 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'].$sep."do=verify&ResNum=".$ResNum;
			if ($price<100)
			{
				echo '<p class="error">مبلغ وارد شده معتبر نیست. حداقل مبلغ پرداختی 100 تومان می باشد.</p>';
				require_once('form.php');
				return;
			}
			$wpdb->query("CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."jahanpay_form` (
			  `id` int(11) NOT NULL AUTO_INCREMENT,
			  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
			  `email` varchar(100) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
			  `mobile` varchar(15) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
			  `price` int(11) NOT NULL,
			  `description` text COLLATE utf8_persian_ci NOT NULL,
			  `ResNum` varchar(50) COLLATE utf8_persian_ci NOT NULL,
			  `RefNum` varchar(50) COLLATE utf8_persian_ci NOT NULL DEFAULT '',
			  `Status` varchar(50) COLLATE utf8_persian_ci NOT NULL DEFAULT 'Pending',
			  PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ;");
			$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
			$res = $client->requestpayment(get_option('api'), $price, $callBackURL, $ResNum);
			if($res['result']==1)
			{
				$wpdb->query("insert into `".$wpdb->prefix."jahanpay_form` (`name`,`email`,`mobile`,`price`,`description`,`ResNum`,`RefNum`) values ('$name','$email','$mobile','$price','$description','$ResNum','".$res['au']."')");
				echo ('<div style="display:none;">'.$res['form'].'</div><script>document.forms["jahanpay"].submit();</script>');
			}
			else
			{
				echo '<p class="error">خطا در دریافت اطلاعات پرداخت از درگاه جهان پی.</p>';
				require_once('form.php');
			}
		}
		else
		{
			echo '<p class="error">خطا : تکمیل تمامی فیلد ها الزامی می باشد.</p>';
			require_once('form.php');
		}
		return;
	}
	elseif (isset($_GET['ResNum'])&&isset($_REQUEST['do'])&&$_REQUEST['do']=='verify')
	{
		$ResNum = $_GET['ResNum'];
		$qay    = $wpdb->get_results("select * from `".$wpdb->prefix."jahanpay_form` where `ResNum`='$ResNum'");
		$pay    = $qay[0];
		$au     = $pay->RefNum;
		$price  = $pay->price;
		$name   = $pay->name;
		$email  = $pay->email;
		$mobile = $pay->mobile;
		$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
		$res    = $client->verification(get_option('api'), $price, $au, $ResNum, $_POST + $_GET );
		if($res['result']==1)
		{
			$wpdb->query("update `".$wpdb->prefix."jahanpay_form` set `RefNum`='$au' , `Status`='Completed' where `ResNum`='$ResNum'");
			echo '<p class="success">پرداخت با موفقیت تکمیل شد. <br /> شماره پیگیری : '.$au.' <br /> شماره سفارش : '.$ResNum.'</p>';
			$mail_headers = "Content-Type: text/plain; charset=utf-8\r\nFrom: ".get_option('admin_email')." <".get_option('admin_email').">\r\nX-Mailer: PHP/".phpversion()."\r\n";
			wp_mail($pay->email, "پرداخت شما تایید شد", "پرداخت شما تایید شد \r\n شماره پیگیری : $au \r\n شماره سفارش : $ResNum", $mail_headers);
		}
		else
		{
			$wpdb->query("update `".$wpdb->prefix."jahanpay_form` set `RefNum`='$au' , `Status`='error ".strval($res['result'])."' where `ResNum`='$ResNum'");
			echo '<p class="error">نتیجه استعلام پرداخت شما نا معتبر می باشد. پرداخت لغو شد.</p>';
		}
	}
	else
	{
		require_once('form.php');
	}
}

add_shortcode('jahanpay_form', 'jahanpay_form');

?>