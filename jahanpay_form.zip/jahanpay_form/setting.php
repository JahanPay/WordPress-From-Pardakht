﻿<div class="wrap">
	<form method="post" action="options.php">
		<table class="form-table">
			<?php wp_nonce_field('update-options');?>
			<tr><th colspan="2"><h3>تنظیمات درگاه جهان پی</h3></th></tr>
			<tr>
				<td width="20%">API درگاه اختصاصی جهان پی:</td>
				<td>
					<input type="text" dir="ltr" name="api" value="<?php echo get_option('api'); ?>"/>
					<br /><span style="font-size: 10px">API دریافتی از جهان پی</span>
				</td>
			</tr>
			<tr>
				<td>
					<p class="submit">
					<input type="hidden" name="action" value="update" />
					<input type="hidden" name="page_options" value="api" />
					<input type="submit" class="button-primary" name="Submit" value="به روز رساني" />
					</p>
				</td>
			</tr>
		</table>
	</form>
</div>